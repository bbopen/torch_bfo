"""PyTorch BFO Optimizer - Bacterial Foraging Optimization for PyTorch 2.8+"""

try:
    from ._version import version as __version__
except ImportError:
    __version__ = "0.0.0+unknown"

from .optimizer import BFO, AdaptiveBFO, HybridBFO
from .debug_utils import enable_debug_mode, disable_debug_mode, print_debug_instructions

__all__ = ["BFO", "AdaptiveBFO", "HybridBFO", "enable_debug_mode", "disable_debug_mode", "print_debug_instructions"]