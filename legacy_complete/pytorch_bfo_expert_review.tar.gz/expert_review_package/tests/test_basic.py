#!/usr/bin/env python3
"""
Basic functionality tests for BFO optimizer
"""

import torch
import sys
sys.path.append('../src')

from optimizer_fixed import BFO


def test_initialization():
    """Test optimizer initialization"""
    print("Testing initialization...")
    
    # Test with different parameter types
    x = torch.nn.Parameter(torch.randn(10))
    optimizer = BFO([x], population_size=20)
    assert optimizer is not None
    assert len(optimizer.param_groups) == 1
    print("✓ Single parameter initialization")
    
    # Test with multiple parameters
    x = torch.nn.Parameter(torch.randn(10))
    y = torch.nn.Parameter(torch.randn(5))
    optimizer = BFO([x, y], population_size=20)
    assert len(optimizer.param_groups[0]['params']) == 2
    print("✓ Multiple parameter initialization")
    
    # Test with CUDA if available
    if torch.cuda.is_available():
        x_cuda = torch.nn.Parameter(torch.randn(10, device='cuda'))
        optimizer = BFO([x_cuda], population_size=20)
        assert optimizer.device == torch.device('cuda:0')
        print("✓ CUDA initialization")


def test_step_execution():
    """Test basic step execution"""
    print("\nTesting step execution...")
    
    x = torch.nn.Parameter(torch.ones(5) * 2.0)
    optimizer = BFO([x], population_size=10, compile_mode=False)
    
    def objective():
        with torch.no_grad():
            return (x ** 2).sum().item()
    
    initial_loss = objective()
    
    # Run one step
    loss = optimizer.step(objective)
    assert isinstance(loss, float)
    assert loss >= 0
    print(f"✓ Step execution (initial: {initial_loss:.4f}, after: {loss:.4f})")


def test_population_sizes():
    """Test various population sizes including odd numbers"""
    print("\nTesting population sizes...")
    
    for pop_size in [2, 3, 5, 10, 15, 20]:
        x = torch.nn.Parameter(torch.randn(5))
        optimizer = BFO([x], population_size=pop_size, compile_mode=False)
        
        def objective():
            with torch.no_grad():
                return (x ** 2).sum().item()
        
        try:
            loss = optimizer.step(objective)
            print(f"✓ Population size {pop_size}: {loss:.4f}")
        except Exception as e:
            print(f"✗ Population size {pop_size} failed: {e}")
            raise


def test_convergence():
    """Test basic convergence behavior"""
    print("\nTesting convergence...")
    
    # Simple quadratic function
    x = torch.nn.Parameter(torch.tensor([5.0, -3.0, 2.0]))
    optimizer = BFO([x], population_size=10, compile_mode=False)
    
    def objective():
        with torch.no_grad():
            return (x ** 2).sum().item()
    
    losses = []
    for i in range(10):
        loss = optimizer.step(objective)
        losses.append(loss)
    
    # Check that loss generally decreases
    initial_loss = losses[0]
    final_loss = losses[-1]
    improvement = (initial_loss - final_loss) / initial_loss * 100
    
    print(f"✓ Initial loss: {initial_loss:.4f}")
    print(f"✓ Final loss: {final_loss:.4f}")
    print(f"✓ Improvement: {improvement:.1f}%")
    
    assert final_loss < initial_loss, "Loss should decrease"


def test_parameter_update():
    """Test that parameters are actually updated"""
    print("\nTesting parameter updates...")
    
    x = torch.nn.Parameter(torch.tensor([1.0, 2.0, 3.0]))
    initial_x = x.data.clone()
    
    optimizer = BFO([x], population_size=5, compile_mode=False)
    
    def objective():
        with torch.no_grad():
            return (x ** 2).sum().item()
    
    # Run several steps
    for _ in range(5):
        optimizer.step(objective)
    
    # Check parameters changed
    assert not torch.allclose(x.data, initial_x), "Parameters should change"
    change = torch.norm(x.data - initial_x).item()
    print(f"✓ Parameters changed by {change:.4f}")


def test_no_gradient_requirement():
    """Test that optimizer works without gradients"""
    print("\nTesting gradient-free operation...")
    
    # Create parameter without requires_grad
    x = torch.nn.Parameter(torch.randn(10), requires_grad=False)
    optimizer = BFO([x], population_size=10, compile_mode=False)
    
    def objective():
        # Ensure no gradients are computed
        with torch.no_grad():
            return (x ** 2).sum().item()
    
    # This should work without errors
    loss = optimizer.step(objective)
    print(f"✓ Gradient-free operation successful: {loss:.4f}")


def main():
    print("BFO Optimizer Basic Tests")
    print("=" * 50)
    
    test_initialization()
    test_step_execution()
    test_population_sizes()
    test_convergence()
    test_parameter_update()
    test_no_gradient_requirement()
    
    print("\n" + "=" * 50)
    print("All basic tests passed! ✓")


if __name__ == "__main__":
    main()