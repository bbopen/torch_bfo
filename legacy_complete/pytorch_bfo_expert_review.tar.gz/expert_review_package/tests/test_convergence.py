#!/usr/bin/env python3
"""
Convergence tests for BFO optimizer on standard test functions
"""

import torch
import numpy as np
import sys
import time
import json

sys.path.append('../src')
from optimizer_fixed import BFO


class TestFunctions:
    """Standard optimization test functions"""
    
    @staticmethod
    def rosenbrock(x, a=1, b=100):
        """Rosenbrock function (global minimum at x=[a, a, ...])"""
        with torch.no_grad():
            loss = 0
            for i in range(len(x) - 1):
                loss += b * (x[i+1] - x[i]**2)**2 + (a - x[i])**2
            return loss.item()
    
    @staticmethod
    def rastrigin(x, A=10):
        """Rastrigin function (global minimum at x=[0, 0, ...])"""
        with torch.no_grad():
            n = len(x)
            return (A * n + torch.sum(x**2 - A * torch.cos(2 * np.pi * x))).item()
    
    @staticmethod
    def ackley(x, a=20, b=0.2, c=2*np.pi):
        """Ackley function (global minimum at x=[0, 0, ...])"""
        with torch.no_grad():
            n = len(x)
            sum1 = torch.sum(x**2)
            sum2 = torch.sum(torch.cos(c * x))
            return (-a * torch.exp(-b * torch.sqrt(sum1 / n)) - 
                    torch.exp(sum2 / n) + a + torch.exp(torch.tensor(1.0))).item()
    
    @staticmethod
    def sphere(x):
        """Sphere function (global minimum at x=[0, 0, ...])"""
        with torch.no_grad():
            return torch.sum(x**2).item()
    
    @staticmethod
    def styblinski_tang(x):
        """Styblinski-Tang function (global minimum at x=[-2.903534, ...])"""
        with torch.no_grad():
            return (0.5 * torch.sum(x**4 - 16*x**2 + 5*x)).item()


def test_function_convergence(func_name, func, dim, initial_range, optimal_value, 
                            iterations=50, population_size=30):
    """Test convergence on a specific function"""
    
    print(f"\nTesting {func_name} function (dim={dim})...")
    
    # Initialize parameters
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    x = torch.nn.Parameter(
        torch.rand(dim, device=device) * (initial_range[1] - initial_range[0]) + initial_range[0]
    )
    
    # Create optimizer
    optimizer = BFO(
        [x],
        population_size=population_size,
        chem_steps=10,
        swim_length=4,
        repro_steps=4,
        elim_steps=2,
        compile_mode=False,
        verbose=False
    )
    
    # Track convergence
    losses = []
    times = []
    
    # Initial loss
    initial_loss = func(x)
    
    # Optimize
    start_time = time.time()
    for i in range(iterations):
        iter_start = time.time()
        loss = optimizer.step(lambda: func(x))
        iter_time = time.time() - iter_start
        
        losses.append(loss)
        times.append(iter_time)
        
        if i % 10 == 0:
            print(f"  Iteration {i}: loss = {loss:.6f} (time: {iter_time:.3f}s)")
    
    total_time = time.time() - start_time
    
    # Calculate metrics
    final_loss = losses[-1]
    improvement = (initial_loss - final_loss) / abs(initial_loss) * 100 if initial_loss != 0 else 0
    distance_from_optimal = abs(final_loss - optimal_value)
    
    # Results
    results = {
        'function': func_name,
        'dimension': dim,
        'initial_loss': initial_loss,
        'final_loss': final_loss,
        'optimal_value': optimal_value,
        'distance_from_optimal': distance_from_optimal,
        'improvement_percent': improvement,
        'iterations': iterations,
        'total_time': total_time,
        'avg_time_per_iter': np.mean(times),
        'final_x': x.data.cpu().numpy().tolist()[:5],  # First 5 components
        'convergence_history': losses[::5]  # Every 5th iteration
    }
    
    print(f"\nResults for {func_name}:")
    print(f"  Initial loss: {initial_loss:.6f}")
    print(f"  Final loss: {final_loss:.6f}")
    print(f"  Optimal value: {optimal_value:.6f}")
    print(f"  Distance from optimal: {distance_from_optimal:.6f}")
    print(f"  Improvement: {improvement:.1f}%")
    print(f"  Total time: {total_time:.2f}s")
    
    return results


def compare_with_torch_optimizers(func_name, func, dim, initial_range, iterations=50):
    """Compare BFO with standard PyTorch optimizers"""
    
    print(f"\nComparing optimizers on {func_name} function...")
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    results = {}
    
    # Test each optimizer
    optimizers = {
        'BFO': lambda p: BFO(p, population_size=20, compile_mode=False, verbose=False),
        'Adam': lambda p: torch.optim.Adam(p, lr=0.1),
        'SGD': lambda p: torch.optim.SGD(p, lr=0.1),
        'RMSprop': lambda p: torch.optim.RMSprop(p, lr=0.1)
    }
    
    for opt_name, opt_creator in optimizers.items():
        print(f"\n  Testing {opt_name}...")
        
        # Reset parameters
        x = torch.nn.Parameter(
            torch.rand(dim, device=device) * (initial_range[1] - initial_range[0]) + initial_range[0],
            requires_grad=(opt_name != 'BFO')  # BFO doesn't need gradients
        )
        
        optimizer = opt_creator([x])
        losses = []
        
        start_time = time.time()
        for i in range(iterations):
            if opt_name == 'BFO':
                # Gradient-free
                loss = optimizer.step(lambda: func(x))
            else:
                # Gradient-based
                optimizer.zero_grad()
                loss_tensor = torch.tensor(func(x), requires_grad=True)
                # Approximate gradient with finite differences
                grad = torch.zeros_like(x)
                eps = 1e-4
                for j in range(len(x)):
                    x_plus = x.clone()
                    x_plus[j] += eps
                    x_minus = x.clone()
                    x_minus[j] -= eps
                    grad[j] = (func(x_plus) - func(x_minus)) / (2 * eps)
                x.grad = grad
                optimizer.step()
                loss = func(x)
            
            losses.append(loss)
        
        total_time = time.time() - start_time
        
        results[opt_name] = {
            'final_loss': losses[-1],
            'improvement': (losses[0] - losses[-1]) / abs(losses[0]) * 100 if losses[0] != 0 else 0,
            'time': total_time,
            'convergence': losses[::10]
        }
        
        print(f"    Final loss: {losses[-1]:.6f}")
        print(f"    Time: {total_time:.2f}s")
    
    return results


def main():
    print("BFO Optimizer Convergence Tests")
    print("=" * 60)
    
    # Test suite configuration
    test_configs = [
        {
            'name': 'Sphere',
            'func': TestFunctions.sphere,
            'dim': 10,
            'range': [-5, 5],
            'optimal': 0.0,
            'iterations': 30
        },
        {
            'name': 'Rosenbrock',
            'func': TestFunctions.rosenbrock,
            'dim': 10,
            'range': [-2, 2],
            'optimal': 0.0,
            'iterations': 50
        },
        {
            'name': 'Rastrigin',
            'func': TestFunctions.rastrigin,
            'dim': 5,
            'range': [-5.12, 5.12],
            'optimal': 0.0,
            'iterations': 50
        },
        {
            'name': 'Ackley',
            'func': TestFunctions.ackley,
            'dim': 5,
            'range': [-32, 32],
            'optimal': 0.0,
            'iterations': 40
        }
    ]
    
    all_results = []
    
    # Run convergence tests
    for config in test_configs:
        result = test_function_convergence(
            config['name'],
            config['func'],
            config['dim'],
            config['range'],
            config['optimal'],
            config['iterations']
        )
        all_results.append(result)
    
    # Compare with other optimizers on Rosenbrock
    comparison = compare_with_torch_optimizers(
        'Rosenbrock',
        TestFunctions.rosenbrock,
        dim=5,
        initial_range=[-2, 2],
        iterations=30
    )
    
    # Save results
    with open('../benchmarks/convergence_results.json', 'w') as f:
        json.dump({
            'test_results': all_results,
            'comparison': comparison
        }, f, indent=2)
    
    print("\n" + "=" * 60)
    print("Convergence tests completed!")
    print("Results saved to benchmarks/convergence_results.json")


if __name__ == "__main__":
    main()