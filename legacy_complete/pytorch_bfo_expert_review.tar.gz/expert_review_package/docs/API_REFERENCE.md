# BFO Optimizer API Reference

## Class: BFO

### `BFO(params, **defaults)`

Bacterial Foraging Optimization (BFO) optimizer for PyTorch.

#### Parameters

- `params` (iterable): Iterable of parameters to optimize or dicts defining parameter groups
- `population_size` (int, default=50): Number of bacteria in the population
- `chem_steps` (int, default=10): Number of chemotactic steps
- `swim_length` (int, default=4): Maximum swimming steps in the same direction
- `repro_steps` (int, default=4): Number of reproduction steps
- `elim_steps` (int, default=2): Number of elimination-dispersal steps
- `elim_prob` (float, default=0.25): Probability of elimination-dispersal
- `attract_factor` (float, default=0.1): Attraction coefficient for swarming
- `repel_factor` (float, default=0.1): Repulsion coefficient for swarming
- `levy_alpha` (float, default=1.5): Lévy flight parameter (1 < α ≤ 2)
- `step_size` (float, default=0.01): Base step size for movement
- `compile_mode` (str, default='default'): torch.compile mode ('default', 'reduce-overhead', 'max-autotune', or False)
- `device` (str, optional): Device to run on ('cuda', 'cpu', or None for auto-detect)
- `verbose` (bool, default=False): Enable debug logging
- `seed` (int, optional): Random seed for reproducibility

#### Methods

##### `step(closure)`

Performs a single optimization step.

**Parameters:**
- `closure` (callable): A closure that reevaluates the model and returns the loss. Required for BFO.

**Returns:**
- `float`: The best fitness value found in this step.

**Example:**
```python
def closure():
    with torch.no_grad():
        loss = (x ** 2).sum()
        return loss.item()

loss = optimizer.step(closure)
```

##### `state_dict()`

Returns the state of the optimizer as a dict.

##### `load_state_dict(state_dict)`

Loads the optimizer state.

#### Internal Methods

##### `_initialize_population()`

Initializes the bacterial population around current parameter values.

##### `_flatten_params()`

Flattens all parameters into a single tensor.

##### `_unflatten_params(flat_params)`

Converts flat tensor back to parameter list.

##### `_levy_flight(size)`

Generates Lévy flight steps for exploration.

##### `_compute_swarming(positions)`

Computes attraction-repulsion forces between bacteria.

##### `_evaluate_closure(closure)`

Evaluates the objective function safely.

##### `_chemotaxis_step(closure, population, best_fitness)`

Performs chemotaxis (tumble and swim) for all bacteria.

##### `_optimization_step(closure, population, best_params, best_fitness, current_iter)`

Main optimization loop (compiled with torch.compile if enabled).

## Class: AdaptiveBFO

Extends BFO with adaptive parameter updates.

### Additional Parameters

- `adapt_chem_steps` (bool, default=True): Adapt chemotactic steps
- `adapt_step_size` (bool, default=True): Adapt step size

### Behavior

- Dynamically adjusts `chem_steps` based on convergence rate
- Modifies `step_size` based on improvement history

## Class: HybridBFO

Combines gradient-based and gradient-free optimization.

### Additional Parameters

- `gradient_weight` (float, default=0.5): Weight for gradient information (0=pure BFO, 1=pure gradient)
- `gradient_clip` (float, optional): Gradient clipping value

### Behavior

- Uses gradients when available to guide bacterial movement
- Falls back to pure BFO when gradients are not available
- Requires closure to compute and return gradients

### Example

```python
def hybrid_closure():
    optimizer.zero_grad()
    loss = model(x)
    loss.backward()
    return loss.item()

optimizer = HybridBFO(model.parameters(), gradient_weight=0.3)
loss = optimizer.step(hybrid_closure)
```

## Utility Functions

### `enable_debug_mode()`

Enables detailed debug logging for the optimizer.

### `disable_debug_mode()`

Disables debug logging.

### `print_debug_instructions()`

Prints instructions for debugging optimization issues.

## Best Practices

1. **Population Size**: Start with 20-50 bacteria. Larger populations explore better but are slower.

2. **Step Size**: Default 0.01 works for most cases. Decrease for fine-tuning, increase for faster exploration.

3. **Closure Function**: Always use `with torch.no_grad()` in closure for gradient-free operation.

4. **Device Selection**: Let the optimizer auto-detect device unless you have specific requirements.

5. **Compilation**: Disable `compile_mode` for debugging, enable for production.

## Common Issues

### Issue: Slow convergence
**Solution**: Increase `population_size` or `chem_steps`

### Issue: Stuck in local optimum
**Solution**: Increase `elim_prob` or `levy_alpha`

### Issue: High GPU memory usage
**Solution**: Reduce `population_size` or disable compilation

### Issue: Parameters not updating
**Solution**: Check closure returns scalar float, not tensor